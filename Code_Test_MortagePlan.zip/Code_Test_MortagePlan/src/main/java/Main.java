public class Main {

    //main method
    public static void  main(String[] args) {

        ReadAndCalculate start=new ReadAndCalculate();
        start.readfileAndCalculate();
    }

}
